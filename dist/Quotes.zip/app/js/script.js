//Fields and Global Varibales
var currDate = new Date();
var productsDataLis = [];
var subject = document.getElementById("subject");
var accountName = document.getElementById("accountName");
var contactName = document.getElementById("contactName");
var dealName = document.getElementById("dealName");
var productType = document.getElementById("productType");
var brand = document.getElementById("brand");
var quoteStage = document.getElementById("quoteStage");
var quoteDate = document.getElementById("quoteDate");
// Route 1&2 Fields
var pumpType = document.getElementById("pumpType");
var applicationType = document.getElementById("applicationType");
var series = document.getElementById("series");
var shaftSpeed = document.getElementById("shaftSpeed");
var size = document.getElementById("size");
var flowRate = document.getElementById("flowRate");
var flowRateUnit = document.getElementById("flowRateUnit");
var specifiGravity = document.getElementById("specifiGravity");
var head = document.getElementById("head");
var headUnit = document.getElementById("headUnit");
var temperature = document.getElementById("temperature");
var temperatureUnit = document.getElementById("temperatureUnit");
var shaftSpeed_API = document.getElementById("shaftSpeed_API");
var shaftSpeedUnit = document.getElementById("shaftSpeedUnit");
var shr = document.getElementById("shr");
var shrUnit = document.getElementById("shrUnit");
var casingMoc = document.getElementById("casingMoc");
var shaftSealing = document.getElementById("shaftSealing");
var impellerMoc = document.getElementById("impellerMoc");
var sealingGlandFlushing = document.getElementById("sealingGlandFlushing");
var lubrication = document.getElementById("lubrication");
var flangeDrilling = document.getElementById("flangeDrilling");
//Table Variables
var pumpLis = document.getElementsByName("pump");
var pumpAmtLis = document.getElementsByName("p_amount");
var accessoryLis = document.getElementsByName("accessory");
var accessoryAmtLis = document.getElementsByName("a_amount");
var sparePartLis = document.getElementsByName("sparePart");
var sparePartAmtLis = document.getElementsByName("s_amount");
var pumpTotal = document.getElementById("pumpTotal");
var accessoryTotal = document.getElementById("accessoryTotal");
var sparePartTotal = document.getElementById("sparePartTotal");
var conMap = {p:pumpAmtLis,a:accessoryAmtLis,s:sparePartAmtLis};
var totalMap = {p:pumpTotal,a:accessoryTotal,s:sparePartTotal};
// Expressions
productType.onchange = typeChange;
quoteDate.valueAsDate  = currDate;
//quoteDate.valueAsDate.toISOString();
require([subject.id,contactName.id,productType.id,"SAD_Yes"],"id");
// Add row button code - start
var rowCount = {pumpBody:1,accessoryBody:1,sparePartBody:1};
function addRow(thisVal,tabBody){
	console.log(productsDataLis);
		rowVal = rowCount[tabBody];
		let conMap = {pumpBody:"pump_",accessoryBody:"accessory_",sparePartBody:"sparePart_"};
		let firstLtr = conMap[tabBody].substring(0,1);
		// if(tabBody == "accessoryBody"){
		// 	var relatedAccessory = [];
		// 	pumpLis.forEach(val => {
		// 		if(val.value){
		// 		// let prdRelateds = getRelatedRecords("Products",val.value,"Accessories_SpareParts").then(rsp => console.log(rsp));
		// 		// productsDataLis.forEach(product => {
		// 		// 	pumpId = product.Pump || {};
		// 		// 	if(product.Product_Category == "Accessory" && pumpId.id == val.value){
		// 		// 		relatedAccessory.push(product);
		// 		// 	}
		// 		// });
		// 		}
		// 	});
		// }
		appendTabRow(tabBody,rowVal);
		rowCount[tabBody]++;
		
		// var categoryMap = {pumpBody:"Pump",accessoryBody:"Accessory",sparePartBody:"Spare Part"};
		// var rowElement = document.getElementById(conMap[tabBody]+rowVal);
		// for (product of productsDataLis){
		// 	if(product.Product_Category == categoryMap[tabBody]){
		// 		var opt = document.createElement("option");
		// 		opt.text = product.Product_Name +"-"+ product.Product_Code;
		// 		opt.value = product.id;
		// 		rowElement.add(opt);
		// 	}
		// }
		
		
		require([conMap[tabBody]+rowVal,firstLtr+"_quantity_"+rowVal],"id");
}
// Add row button code - end
document.getElementById("searchBtn").onclick = event => {
	$('.apiTable').show();
var api = fetch("http://test.makemypump.com:8288//api/Curve/GetCurveTest?fld1=Horizontal&fld2=Water&fld3=70&fld4=m3/hr&fld5=30&fld6=m&fld7=40&fld8=&fld9=1&fld10=1450");
api.then(x => x.json(),y => console.log(y)).then(d => {
	console.log(d.Table1);
	var rtn = d.Table1.map((val,index) => {
		let visCln = ["SERIES","SIZE","SPEED","DIA","EFFICIENCY","SHAFT_POWER"];
		let tabRow = '<tr>';
		for(obj in val){
			let objVal = val[obj];
			let display = "none";
			if(visCln.includes(obj)){
				display = "true";
			}
			tabRow += '<td style="display: '+display+';"><input type="text" name="'+obj+'" value="'+objVal+'" id="'+obj+'_'+index+'" index="'+index+'" class="form-control" ></td>';
		}
		tabRow += '<td><input type="checkbox" class="btn-check" name="checkBtn" id="checkBtn_'+index+'" index="'+index+'" onClick="checkApiRow(this)"></td>';
		tabRow += '</tr>';
		return tabRow;
	});
	// console.log(rtn);
	document.getElementById("apiBody").innerHTML = rtn.join("");
});
}
function submitFun(thisVal){
	// var fields = document.getElementsByClassName("important");
	// for(i of fields){
	// 	if(i.value == ""){
	// 		return false;
	// 	}
	// }
}
	// Subscribe to the EmbeddedApp onPageLoad event before initializing the widget
ZOHO.embeddedApp.on("PageLoad",function(etData){
	asyncFun = async () =>{ 
		// console.log("above");
		// ZOHO.CRM.API.getRelatedRecords({Entity:"Contacts",RecordID:"156506000000319001",RelatedList:"Deals"})
		// .then(data => {
		// 	console.log(data);
		// 	console.log("below");
		// });
		
	// Load optionis
		var productsFields = await getFields("Products");
		for(let field of productsFields){
			if(field.api_name == "Manufacturer"){
				let pickListValues = field.pick_list_values;
				for(let i of pickListValues){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					brand.add(opt);
					}
				}
			}
		}
		var quotesFields = await getFields("Quotes");
		for(let field of quotesFields){
			if(field.api_name == "Quote_Stage"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					quoteStage.add(opt);
					}
				}
			}
			if(field.api_name == "Flow_Rate_Unit"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					flowRateUnit.add(opt);
					}
				}
			}
			if(field.api_name == "Head_Unit"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					headUnit.add(opt);
					}
				}
			}
			if(field.api_name == "Temperature_Unit"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					temperatureUnit.add(opt);
					}
				}
			}
			if(field.api_name == "Shaft_Speed"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					shaftSpeed_API.add(opt);
					}
				}
			}
			if(field.api_name == "Shaft_Speed_Unit"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					shaftSpeedUnit.add(opt);
					}
				}
			}
			if(field.api_name == "Solid_Handling_Requirement_Unit"){
				for(let i of field.pick_list_values){
					if(i.actual_value != "-None-"){
					let opt = document.createElement("option");
					opt.text = i.display_value;
					opt.value = i.actual_value;
					shrUnit.add(opt);
					}
				}
			}

		}
	productsDataLis = await getRecords("Products");
	for (product of productsDataLis){
		var eleAndCat = {Pump:pumpLis,Accessory:accessoryLis,Spare_Part:sparePartLis};
		for(key in eleAndCat){
		if(product.Product_Category == key.replace("_"," ")){
			let opt = document.createElement("option");
			opt.text = product.Product_Name +"-"+ product.Product_Code;
			opt.value = product.id;
			for(let value of eleAndCat[key]){
					value.add(opt);
			}
		}
	}
	}
	var crmContacts = await getRecords("Contacts");
	for (let data of crmContacts){
		let opt = document.createElement("option");
		opt.text = data.Full_Name;
		opt.value = data.id;
		if(crmContacts.length == 1){
			opt.selected = true;
		}
		contactName.add(opt);
	}
	var crmAccounts = await getRecords("Accounts");
	for (let data of crmAccounts){
		let opt = document.createElement("option");
		opt.text = data.Account_Name;
		opt.value = data.id;
		accountName.add(opt);
	}
	var crmDeals = await getRecords("Deals");
	for (let data of crmDeals){
		let opt = document.createElement("option");
		opt.text = data.Deal_Name;
		opt.value = data.id;
		dealName.add(opt);
	}
	var crmPumpTypes = await getRecords("Pump_Types");
	var crmApplicationTypes = await getRecords("Application_Types");
	var crmSeries = await getRecords("Series");
	var crmSizes = await getRecords("Sizes");
	for (let data of crmPumpTypes){
		let opt = document.createElement("option");
		opt.text = data.Name;
		opt.value = data.id;
		pumpType.add(opt);
	}
	pumpType.onchange = event => {
		// Application Type & Series
		$("#applicationType").empty();
		$("#series").empty();
		let opt = document.createElement("option");
		opt.text = "-None-";
		opt.value = "";
		let optCl = opt.cloneNode(true);
		applicationType.add(opt);
		series.add(optCl);
		for (let data of crmApplicationTypes){
			let opt = document.createElement("option");
			opt.text = data.Name;
			opt.value = data.id;
			applicationType.add(opt);
		}
		for (let data of crmSeries){
			let opt = document.createElement("option");
			opt.text = data.Name;
			opt.value = data.id;
			series.add(opt);
		}

	}
	// Route 2 no API
	var crmSeriesSingle;
	series.onchange = async event => {
		$("#shaftSpeed").empty();
		$("#casingMoc").empty();
		$("#shaftSealing").empty();
		$("#lubrication").empty();
		$("#flangeDrilling").empty();
		let opt = document.createElement("option");
		opt.text = "-None-";
		opt.value = "";
		casingMoc.add(opt.cloneNode(true));
		shaftSealing.add(opt.cloneNode(true));
		lubrication.add(opt.cloneNode(true));
		flangeDrilling.add(opt.cloneNode(true));
		shaftSpeed.add(opt);
		var shaftSpeedLis = [];
		if(series.value){
			crmSizes.forEach(val => shaftSpeedLis = shaftSpeedLis.concat(val.Shaft_Speed));
			shaftSpeedLis = [...new Set(shaftSpeedLis)];
			shaftSpeedLis.forEach(val => {
			let opt = document.createElement("option");
			opt.text = val;
			opt.value = val;
			shaftSpeed.add(opt);
			});
			crmSeriesSingle = await getSingleRecord("Series",series.value);
			console.log(crmSeriesSingle);
			crmSeriesSingle.Series_MoC.forEach(val => {
				let opt = document.createElement("option");
				opt.text = val.Casing_MoC;
				opt.value = val.Casing_MoC;
				casingMoc.add(opt);
	
			});
			crmSeriesSingle.Series_Seal_Flushing.forEach(val => {
				let opt = document.createElement("option");
				opt.text = val.Shaft_Sealing;
				opt.value = val.Shaft_Sealing;
				shaftSealing.add(opt);
	
			});
			crmSeriesSingle.Bearing_Lubrication.forEach(val => {
				let opt = document.createElement("option");
				opt.text = val;
				opt.value = val;
				lubrication.add(opt);
			});
			crmSeriesSingle.Flange_Drilling.forEach(val => {
				let opt = document.createElement("option");
				opt.text = val;
				opt.value = val;
				flangeDrilling.add(opt);
			});
			
		}
	}
	shaftSpeed.onchange = event => {
		$("#size").empty();
		let opt = document.createElement("option");
		opt.text = "-None-";
		opt.value = "";
		size.add(opt);
		for (let data of crmSizes){
			if(data.Shaft_Speed.includes(event.target.value)){
			let opt = document.createElement("option");
			opt.text = data.Name;
			opt.value = data.id;
			size.add(opt);
			}
		}

	}
	casingMoc.onchange = event => {
		$("#impellerMoc").empty();
		let opt = document.createElement("option");
		opt.text = "-None-";
		opt.value = "";
		impellerMoc.add(opt);
		crmSeriesSingle.Series_MoC.forEach(val => {
			if(val.Casing_MoC == casingMoc.value){
				val.Impeller_MoC.forEach(impellerVal => {
					let opt = document.createElement("option");
					opt.text = impellerVal;
					opt.value = impellerVal;
					impellerMoc.add(opt);
				});
			}

		});
	}
	shaftSealing.onchange = event => {
		$("#sealingGlandFlushing").empty();
		let opt = document.createElement("option");
		opt.text = "-None-";
		opt.value = "";
		sealingGlandFlushing.add(opt);
		crmSeriesSingle.Series_Seal_Flushing.forEach(val => {
			if(val.Shaft_Sealing == shaftSealing.value){
				val.Mechanical_Seal_Flushing.forEach(sealFlushVal => {
					let opt = document.createElement("option");
					opt.text = sealFlushVal;
					opt.value = sealFlushVal;
					sealingGlandFlushing.add(opt);
				});
			}
		});
	}
	// Route 1 API
	var crmAppTypeSingle;
	applicationType.onchange = async event => {
		temperature.value = "";
		shr.value = "";
		specifiGravity.value = "";
		if(applicationType.value){
		crmAppTypeSingle = await getSingleRecord("Application_Types",applicationType.value);
		}
	}
	flowRate.onchange = event => {
		let flowRateVal = Number(flowRate.value);
		let flowRateMin = crmPumpTypes[0].Flow_Rate_Min;
		let flowRateMax = crmPumpTypes[0].Flow_Rate_Max;
		if(flowRateVal < flowRateMin || flowRateVal > flowRateMax){
			swal("Enter Flow Rate Value " + flowRateMin + " - " + flowRateMax,"","warning");
			flowRate.value = "";
		}
	}
	head.onchange = event => {
		let headVal = Number(head.value);
		let headMin = crmPumpTypes[0].Head_Min;
		let headMax = crmPumpTypes[0].Head_Max;
		if(headVal < headMin || headVal > headMax){
			swal("Enter Head Value " + headMin + " - " + headMax,"","warning");
			head.value = "";
		}
	}
	temperature.onchange = event => {
		let tempVal = Number(temperature.value);
		if(applicationType.value){
			let tempMin = crmAppTypeSingle.Temperature_Min;
			let tempMax = crmAppTypeSingle.Temperature_Max;
			if(tempVal < tempMin || tempVal > tempMax){
				swal("Enter temperature value "+ tempMin+" - "+tempMax,"","warning");
				temperature.value = "";
			}
			else{
				crmAppTypeSingle.Seal_Flushing.forEach(val => {
					let tempMin = val.Temperature_Min;
					let tempMax = val.Temperature_Max;
					if(tempVal >= tempMin && tempVal <= tempMax){
						$("#sealingGlandFlushing").empty();
						let optempty = document.createElement("option");
						optempty.text = "-None-";
						optempty.value = "";
						sealingGlandFlushing.add(optempty);
						let opt = document.createElement("option");
						opt.text = val.Mechanical_Seal_Flushing;
						opt.value = val.Mechanical_Seal_Flushing;
						sealingGlandFlushing.add(opt);
					}
				});
			}
		}
		else{
			swal("Select application type","","warning");
			temperature.value = "";
		}

	}
	shr.onchange = event => {
		let shrVal = Number(shr.value);
		if(applicationType.value){
			if(shrVal < 0 || shrVal > crmAppTypeSingle.Solid_Handling_Requirement_SHR)
			{
				swal("Enter Solid Handling Requirement Value 0 - " + crmAppTypeSingle.Solid_Handling_Requirement_SHR + "","","warning");
				shr.value = "";
			}
		}
		else{
			swal("Select application type","","warning");
			shr.value = "";
		}
	}
	specifiGravity.onchange = event => {
		let specifiGravityVal = Number(specifiGravity.value);
		if(applicationType.value){
			let SpGMin = crmAppTypeSingle.Specific_Gravity_Min;
			let SpGMax = crmAppTypeSingle.Specific_Gravity_Max;
			if(specifiGravityVal < SpGMin || specifiGravityVal > SpGMax){
				swal("Enter Specific Gravity Value "+ SpGMin+" - "+SpGMax,"","warning");
				specifiGravity.value = "";
			}
		}
		else{
			swal("Select application type","","warning");
			specifiGravity.value = "";
		}

	}
	// swal("Good job!", "You clicked the button!", "info");
	// accountName.onchange = async event => {
	// 	var accID = event.target.value;
	// 	$("#contactName").empty();
	// 	let opt = document.createElement("option");
	// 	opt.text = "-None-";
	// 	opt.value = "";
	// 	contactName.add(opt);
	// 	if(accID){
	// 		for (let data of await getRelatedRecords("Accounts",accID,"Contacts")){
	// 			let opt = document.createElement("option");
	// 			opt.text = data.Full_Name;
	// 			opt.value = data.id;
	// 			contactName.add(opt);
	// 		}
	// 	}

	// }
}
asyncFun();
});
//initialize the widget
ZOHO.embeddedApp.init();